public class HobbitBolseiro extends HobbitContador
{
  public int maiorNumeroMultiplo(int numero){
      
      return numero;
    }
}
