public enum Status
{
    VIVO, MORTO
}
