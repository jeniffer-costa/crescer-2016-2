public enum TipoOrdenacao
{
    ASCENDENTE,DESCENDENTE;
}
